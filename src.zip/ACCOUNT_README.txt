Install: npm i react-router-dom lucide-react
Wrap in src/main.tsx with <AuthProvider> from './context/AuthContext'.
Replace src/components/Navigation.tsx with this version.
Optional route: <Route path="/account" element={<AccountPage/>} />
Account modal supports Google (mock) and 'Skip login (dev)'. Replace src/lib/auth.ts with your real provider later.
